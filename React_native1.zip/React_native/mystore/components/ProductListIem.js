import React from 'react';
import PropTypes from 'prop-types';
import {View, Text, Image} from 'react-native';

import { FontAwesome } from '@expo/vector-icons';

function ProductListItem ({ product }){
    return(
        <View style={{flex:1, flexDirection:"row", marginRight: 50, marginLeft: 20}}>
            <Image
                style={{width:100, height:100}}
                source={{uri: `http://172.16.34.228:4000/images/${product.image}`}}
                resizeMode = "center"
            />
            <View style={{flex:1, flexDirection:"row"}}>
                <Text
                    style={{ marginBottom: 25, overflow: "hidden", marginLeft:15, marginRight: 5}}
                    key={product.id}
                >
                    {product.title}
                </Text>
                <FontAwesome name="heart-o" size={32} color="green" style={{marginLeft: 5}}/> 
            </View>
        </View>
    )
}

ProductListItem.protoTypes = {
    product: PropTypes.object.isRequired
};

export default ProductListItem;


