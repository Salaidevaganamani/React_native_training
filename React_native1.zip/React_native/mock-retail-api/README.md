Local Setup
-----------

git clone https://github.com/baluragala/mock-retail-api.git

cd mock-retail-api

npm install

npm start
