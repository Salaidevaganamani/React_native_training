let calculatePrice = ({price, tax, discount = 10}={}) => {
    let = taxablePrice = price - (price * (discount / 100));
    let = priceWithTax =  taxablePrice + (taxablePrice * (tax / 100));

    return priceWithTax;
};

calculatePrice({price:10, tax:20});

